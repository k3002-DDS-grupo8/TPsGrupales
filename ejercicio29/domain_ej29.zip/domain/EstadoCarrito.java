package domain;

public enum EstadoCarrito {
    CREADO,
    CONFIRMADO,
    PAGADO
}
