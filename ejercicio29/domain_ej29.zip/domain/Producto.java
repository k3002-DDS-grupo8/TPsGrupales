package domain;

public class Producto {
    private String nombre;
}
